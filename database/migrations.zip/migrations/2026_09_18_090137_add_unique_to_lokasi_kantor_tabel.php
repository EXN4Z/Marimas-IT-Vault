<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('lokasi_kantor', function (Blueprint $table) {
            $table->unique('alamat');
            $table->unique('link');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('lokasi_kantor', function (Blueprint $table) {
            $table->dropUnique(['alamat']);
            $table->dropUnique(['link']);
        });
    }
};
